Authors: Jack Gularte and Anthony Caballero
Date: Feburary 2nd 
Class: CPSC 3500
Assignment: Project Two

Strengths: Sorting, Round Robin, FCFS, SRTF
Weakness: Printing the correct statistics

Jack: Preprocessing, Sorting, SRTF
Tony: Round Robin, FCFS